================================================================================
                    SKILLCRAFT INTERNSHIP TASK 02
                 TITANIC EDA (EXPLORATORY DATA ANALYSIS)
================================================================================

================================================================================
📌 OBJECTIVE
================================================================================
Perform data cleaning and exploratory data analysis (EDA) on the Titanic 
dataset to explore relationships between variables and identify patterns 
and trends in the data.

================================================================================
🛠️ TOOLS USED
================================================================================
- Python
- Pandas
- Matplotlib
- Seaborn

================================================================================
📁 FILES INCLUDED
================================================================================
- titanic_cleaned.csv  - Dataset
- titanic_eda.py       - Python script
- titanic_analysis.png - Generated output chart (4 visualizations)
- README.text           - Project documentation

================================================================================
🚀 HOW TO RUN
================================================================================

Step 1: Install dependencies
   pip install pandas matplotlib seaborn

Step 2: Run the script
   python titanic_eda.py

Step 3: View output
   The chart will be displayed and saved as titanic_analysis.png

================================================================================
📊 OUTPUT
================================================================================
Four comprehensive visualizations showing:

   1. Overall survival count
   2. Survival by gender
   3. Survival by passenger class
   4. Survival rate by family size

================================================================================
📈 KEY FINDINGS
================================================================================

| Factor              | Survival Rate |
|---------------------|---------------|
| Women               |     74%       |
| Men                 |     19%       |
| 1st Class           |     63%       |
| 2nd Class           |     47%       |
| 3rd Class           |     24%       |
| Children (<18)      |     54%       |
| Adults (18+)        |     35%       |
| With Family         |     52%       |
| Alone               |     30%       |

================================================================================
📝 CONCLUSION
================================================================================
The EDA reveals clear patterns in Titanic survival:

1. GENDER is the strongest predictor - Women survived at much higher rates
2. CLASS indicates socioeconomic advantage - Wealthier passengers had better access to lifeboats
3. AGE matters - Children were prioritized during evacuation
4. FAMILY SIZE shows optimal survival for small families (2-4 people)

