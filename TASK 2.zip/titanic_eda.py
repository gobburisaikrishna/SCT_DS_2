# Task 02: EDA - Titanic Dataset
# Takes input file: titanic_cleaned.csv

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from google.colab import files

print("="*50)
print("TASK 02: EDA - TITANIC DATASET")
print("="*50)

# ============================================
# FILE INPUT LINES (ADDED)
# ============================================
print("\n📂 Please upload your titanic_cleaned.csv file")
uploaded = files.upload()

for filename in uploaded.keys():
    df = pd.read_csv(filename)
    print(f"\n✅ Loaded: {filename}")
    break

print(f"📊 Dataset shape: {df.shape}")
print(df.head(3))

# ============================================
# DATA CLEANING & FEATURE ENGINEERING
# ============================================
print("\n" + "="*50)
print("DATA CLEANING & FEATURE ENGINEERING")
print("="*50)

# Handle missing values
df['age'].fillna(df['age'].median(), inplace=True)

# Create family_size column if not exists
if 'family_size' not in df.columns:
    df['family_size'] = df['sibsp'] + df['parch'] + 1

print(f"✅ Dataset ready: {df.shape}")
print(f"Columns: {df.columns.tolist()}")

# ============================================
# BASIC STATISTICS
# ============================================
print("\n" + "="*50)
print("BASIC STATISTICS")
print("="*50)

print(f"Total passengers: {len(df)}")
print(f"Survived: {df['survived'].sum()} ({df['survived'].mean()*100:.1f}%)")
print(f"Not survived: {len(df) - df['survived'].sum()} ({(1-df['survived'].mean())*100:.1f}%)")

# ============================================
# CREATE VISUALIZATIONS
# ============================================
print("\n" + "="*50)
print("GENERATING CHARTS")
print("="*50)

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Titanic Survival Analysis - EDA', fontsize=14, fontweight='bold')

# Chart 1: Survival count
ax1 = axes[0, 0]
df['survived'].value_counts().plot(kind='bar', ax=ax1, color=['#E74C3C', '#2ECC71'], edgecolor='black')
ax1.set_title('1. Overall Survival')
ax1.set_ylabel('Count')
ax1.set_xticklabels(['Died', 'Survived'], rotation=0)

# Chart 2: Survival by gender
ax2 = axes[0, 1]
pd.crosstab(df['sex'], df['survived']).plot(kind='bar', ax=ax2, color=['#E74C3C', '#2ECC71'], edgecolor='black')
ax2.set_title('2. Survival by Gender')
ax2.set_xlabel('Gender')
ax2.set_ylabel('Count')
ax2.set_xticklabels(['Female', 'Male'], rotation=0)
ax2.legend(['Died', 'Survived'])

# Chart 3: Survival by class
ax3 = axes[1, 0]
pd.crosstab(df['pclass'], df['survived']).plot(kind='bar', ax=ax3, color=['#E74C3C', '#2ECC71'], edgecolor='black')
ax3.set_title('3. Survival by Class')
ax3.set_xlabel('Passenger Class')
ax3.set_ylabel('Count')
ax3.set_xticklabels(['1st', '2nd', '3rd'], rotation=0)
ax3.legend(['Died', 'Survived'])

# Chart 4: Survival by family size
ax4 = axes[1, 1]
family_survival = df.groupby('family_size')['survived'].mean()
family_survival.plot(kind='bar', ax=ax4, color='#3498DB', edgecolor='black')
ax4.set_title('4. Survival Rate by Family Size')
ax4.set_xlabel('Family Size')
ax4.set_ylabel('Survival Rate')
ax4.set_ylim(0, 1)

plt.tight_layout()
plt.savefig('titanic_eda.png', dpi=200, bbox_inches='tight')
print("✅ Chart saved: titanic_eda.png")

plt.show()

print("\n" + "="*50)
print("✅ TASK 02 COMPLETED!")
print("="*50)